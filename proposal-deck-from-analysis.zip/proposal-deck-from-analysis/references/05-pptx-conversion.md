# HTML → PPTX 変換手順

STEP 3 で HTMLDeck から編集可能なPPTXを生成する手順。

---

## 前提

- 入力: `/mnt/user-data/outputs/proposal_v[N]_19pages.html`
- 出力: `/mnt/user-data/outputs/proposal_v[N]_19pages.pptx`
- ライブラリ: `python-pptx`（PPTX生成）+ `playwright` または `selenium`（HTML/SVGをPNG化）
- 既存skill: `/mnt/skills/public/pptx/SKILL.md` を必ず先に `view` する

---

## 変換アプローチ

### 方針：ハイブリッド変換

PPTXの「編集可能性」を最大化するため、要素ごとに以下のように変換：

| HTML/SVG要素 | PPTX変換方法 |
|---|---|
| スライドタイトル | テキストボックス（編集可能） |
| メインメッセージ | テキストボックス（編集可能） |
| フッター | テキストボックス（編集可能） |
| シンプルな矩形・テキスト（SVG `<rect>` + `<text>`） | PPTXシェイプ + テキスト（編集可能） |
| 複雑な概念図（5要素以上の組み合わせ） | PNGとして埋め込み（編集不可だが見た目維持） |
| 表（HTML `<table>` または SVG表） | PPTXテーブル（編集可能） |

### 判断基準（編集可能 vs PNG）

```python
def should_convert_to_shapes(svg_element):
    rect_count = len(svg_element.findall('.//rect'))
    text_count = len(svg_element.findall('.//text'))
    line_count = len(svg_element.findall('.//line'))
    polygon_count = len(svg_element.findall('.//polygon'))
    total = rect_count + text_count + line_count + polygon_count
    
    # 50要素以下: PPTXシェイプに変換
    # 50要素超: PNG化して埋め込み
    return total <= 50
```

---

## 実装手順

### STEP A: HTMLDeckの解析

```python
from bs4 import BeautifulSoup

with open(html_path, "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f.read(), "html.parser")

slides = soup.find_all("div", class_="slide")
print(f"検出: {len(slides)}枚のスライド")
```

### STEP B: 各スライドの要素を抽出

```python
for i, slide in enumerate(slides):
    title = slide.find("div", class_="slide-title").get_text(strip=True)
    subtitle_html = str(slide.find("div", class_="slide-subtitle"))
    svg = slide.find("svg")
    footer = slide.find("div", class_="slide-footer")
    
    # PPTXに変換
    add_pptx_slide(prs, title, subtitle_html, svg, footer, page_num=i+1)
```

### STEP C: PPTX組み立て

```python
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor

# A4ヨコ（13.33in × 7.5in = 16:9）
prs = Presentation()
prs.slide_width = Inches(13.33)
prs.slide_height = Inches(7.5)

blank_layout = prs.slide_layouts[6]  # Blank

for slide_data in slides_data:
    slide = prs.slides.add_slide(blank_layout)
    
    # タイトル
    title_box = slide.shapes.add_textbox(
        Inches(0.4), Inches(0.3), Inches(12.5), Inches(0.6)
    )
    title_box.text_frame.text = slide_data["title"]
    title_box.text_frame.paragraphs[0].font.size = Pt(28)
    title_box.text_frame.paragraphs[0].font.bold = True
    title_box.text_frame.paragraphs[0].font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)
    
    # メインメッセージ
    msg_box = slide.shapes.add_textbox(
        Inches(0.4), Inches(0.95), Inches(12.5), Inches(0.7)
    )
    msg_tf = msg_box.text_frame
    msg_tf.word_wrap = True
    add_styled_text(msg_tf, slide_data["subtitle_html"])
    
    # チャート（SVG → PPTX要素 or PNG）
    if slide_data["svg"]:
        if should_convert_to_shapes(slide_data["svg"]):
            convert_svg_to_pptx_shapes(slide, slide_data["svg"])
        else:
            png_path = svg_to_png(slide_data["svg"], output_dir="/tmp/")
            slide.shapes.add_picture(
                png_path, Inches(0.4), Inches(1.7),
                width=Inches(12.5)
            )
    
    # フッター
    add_footer(slide, slide_data["footer"], page_num)

prs.save(output_pptx_path)
```

### STEP D: SVG → PNG（複雑な図解用）

```python
import asyncio
from playwright.async_api import async_playwright

async def svg_to_png(svg_html: str, output_path: str, width=1280, height=620):
    html = f"""
    <html><body style="margin:0; padding:0;">
    {svg_html}
    </body></html>
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context(viewport={"width": width, "height": height})
        page = await context.new_page()
        await page.set_content(html)
        await page.screenshot(path=output_path, omit_background=True)
        await browser.close()
    return output_path
```

### STEP E: SVG → PPTXシェイプ（シンプル図解用）

```python
def convert_svg_to_pptx_shapes(slide, svg_element):
    """SVGの<rect>, <text>, <line>をPPTXのMSO_SHAPEに変換"""
    from pptx.enum.shapes import MSO_SHAPE
    
    # viewBoxからスケール係数を計算
    viewbox = svg_element.get("viewBox", "0 0 800 380").split()
    vb_w, vb_h = float(viewbox[2]), float(viewbox[3])
    
    chart_left = Inches(0.4)
    chart_top = Inches(1.7)
    chart_width = Inches(12.5)
    chart_height = Inches(5.5)
    
    scale_x = chart_width / vb_w
    scale_y = chart_height / vb_h
    
    # <rect> を PPTX矩形に変換
    for rect in svg_element.find_all("rect"):
        x = float(rect.get("x", 0)) * scale_x + chart_left
        y = float(rect.get("y", 0)) * scale_y + chart_top
        w = float(rect.get("width", 0)) * scale_x
        h = float(rect.get("height", 0)) * scale_y
        fill = rect.get("fill", "#FFFFFF")
        
        shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
        shape.fill.solid()
        shape.fill.fore_color.rgb = hex_to_rgb(fill)
        shape.line.fill.background()  # 罫線なし
    
    # <text> を PPTXテキストボックスに変換
    for text in svg_element.find_all("text"):
        x = float(text.get("x", 0)) * scale_x + chart_left
        y = float(text.get("y", 0)) * scale_y + chart_top
        font_size = float(text.get("font-size", 11))
        content = text.get_text()
        
        tb = slide.shapes.add_textbox(x, y - Pt(font_size).emu, Inches(2), Inches(0.3))
        tb.text_frame.text = content
        tb.text_frame.paragraphs[0].font.size = Pt(font_size)
    
    # <line> も同様...
```

---

## 既存pptx skill との連携

`/mnt/skills/public/pptx/SKILL.md` を必ず先に読み込み、そのスキルが提供する以下の機能を使う：

- スライドサイズ・レイアウトの基本設定
- マスタースライドの利用
- フォント埋め込み
- カラーテーマの統一

このSKILLは「19枚提案書 → PPTX」の変換ロジックに集中し、PPTX生成の基盤は pptx skill に任せる。

---

## 出力後のチェック

```python
from pptx import Presentation

prs = Presentation(output_pptx_path)
assert len(prs.slides) == 19, f"期待19枚、実際{len(prs.slides)}枚"

for i, slide in enumerate(prs.slides):
    title_found = False
    for shape in slide.shapes:
        if shape.has_text_frame and shape.text_frame.text.strip():
            title_found = True
            break
    assert title_found, f"P{i+1}にテキストがない"

print("✅ PPTX 検証OK")
```

---

## トラブルシューティング

| 問題 | 原因 | 対処 |
|---|---|---|
| 日本語フォントが文字化け | フォント埋め込みなし | `Pt`で指定するfont nameを `'Hiragino Sans'` に統一 |
| SVGの色がPPTXで再現されない | hex_to_rgb の変換漏れ | `var(--xxx)` のCSS変数解決を関数化して全色対応 |
| ファイルが100MB超える | PNG解像度過剰 | PNG width を 1280px に統一、`quality=85` で保存 |
| 図形がスライド外にはみ出す | viewBoxのスケール計算誤り | `chart_left`, `chart_top`, `chart_width`, `chart_height` の単位（Inches/Emu）を統一 |
| テキストが折り返されない | `word_wrap=True` 未設定 | 全テキストフレームに `text_frame.word_wrap = True` |

---

## ファイル名規則

- `proposal_v1_19pages.pptx` （初回）
- `proposal_v2_19pages.pptx` （ユーザー修正後）
- 命名は HTMLDeck と完全一致させる（拡張子のみ違い）
